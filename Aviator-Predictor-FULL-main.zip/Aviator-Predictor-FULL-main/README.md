
<div align="center">

# Aviator Predictor

![logo-aviator](https://github.com/MuckPro/aviat/assets/138373919/f247efa9-e00d-44ae-bd9f-b600f6d854a2)

[![Build Status](https://ci.appveyor.com/api/projects/status/1yii01mrx6ied4bt/branch/master?svg=true)](https://ci.appveyor.com/project/jbreckel/flow-result-checker/branch/master) 

## What is the Aviator Betting Game?
The Aviator game has taken the online casino world by storm since its inception in 2019. Created by [Scribe Gaming](https://spribe.co/games/aviator), Aviator has disrupted the betting and gaming space like no other game in history. Its popularity can be seen across the world, with over 2,000 betting and casino companies adding Aviator to their games portfolio, and now over 10 million players.

## How to Play 
Aviator is a new kind of social multiplayer game consisting of an increasing curve that can collapse at any moment. When the round starts, a multiplier scale starts to grow. The player must earn money before the lucky plane flies away.

## Prediction Tool

This Tool shows you how many multipliers the lucky plane will fly to make it easier for you to earn money. Thus, you will secure your money before the lucky plane flies away because you know how many multipliers it will fly.

## Setup

1. Download this repository as zip to your local machine.
2. Go to the project folder.
3. Open Project.
4. Use the shortcut `Ctrl + Shift + B` to compile the project.

## Usage

1. Once the project is compiled in Visual Studio, you can launch the Aviator Predictor Application by pressing `F5`.

2. After launching, the Login Screen will appear.

3. Username: ```admin```

4. Password: You can find out by pressing Forgot Password

5. After logging in, enter the seed of the latest game in the ```LAST GAME SEED``` section and click the ```Next``` button. If you see Done, you can click the START button and see the next multiplier.

## Preview

![aviator](https://github.com/MuckPro/aviat/assets/138373919/57c4ba1a-bd7e-4621-97b7-225c987c6a67)


![proof](https://github.com/MuckPro/aviat/assets/138373919/086675dc-8e78-41a7-a807-f5c601c49ea0)




https://github.com/MuckPro/aviat/assets/138373919/85f98df3-3a62-446c-b522-857b85b27a7f

## Attention
I advise you to use this vehicle without attracting attention. Or your account may be blocked.
 
![av-compass](https://github.com/MuckPro/aviat/assets/138373919/539b2a2a-9f54-4dd4-a3d6-e066ff71eb87)

### Contribution

Feel free to contribute by forking the repository and submitting pull requests.

### License

This project is licensed under the [MIT License](LICENSE).


![cc9a48fa-cc15-4086-8fae-021956591330](https://github.com/MuckPro/aviat/assets/138373919/0f34bcdc-3450-4d1e-868c-1e45f0eed2dd)

![pro](https://github.com/MuckPro/aviat/assets/138373919/5cd95252-5b72-4007-92b9-c83f40a2f889)



